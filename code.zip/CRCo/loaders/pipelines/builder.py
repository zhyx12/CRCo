#
# ----------------------------------------------
from mmcls.datasets import PIPELINES as CLS_PIPELINES

if __name__ == "__main__":
    pass
